



	<header class="featured-hero" role="banner" style="background:url(<?php the_field( 'page_header_background_image' ); ?>);background-color:gray;">
        <div id="featured-background-overlay">
        <div class="main-container">
            <div class="title_container">
              <h1 class="entry-title"><?php the_title(); ?></h1>
            </div>
        </div>
    </div>
	</header>
